using project_23;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string companyName;
            string dateOfStart;
            string bulstatt;
            string ownerName;
            double firstCapital;
            double currentCapital;

            if (radioButton1.Checked)
            {
                companyName = textBox1.Text;
                dateOfStart = textBox2.Text;
                bulstatt = textBox3.Text;
                ownerName = textBox4.Text;
                firstCapital = double.Parse(textBox5.Text);
                currentCapital = double.Parse(textBox6.Text);

                SoleTrader soleTrader = new SoleTrader(companyName, dateOfStart, bulstatt, ownerName, firstCapital, currentCapital);
            }
            else if (radioButton2.Checked)
            {
                textBox5.Enabled = false;
                companyName = textBox1.Text;
                dateOfStart = textBox2.Text;
                bulstatt = textBox3.Text;
                ownerName = textBox4.Text;
                textBox5.Enabled = false;
                currentCapital = double.Parse(textBox6.Text);

                LimitedCompany limitedCompany = new LimitedCompany(companyName, dateOfStart, bulstatt, ar);
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
