﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_23
{
    public class SoleTrader : Company
    {
        private string ownerName;
        private double currentCapital;
        private double firstCapital;

        public SoleTrader(string name, string dateOfStart, string bullstatt, string ownerName, double firstCapital, double currentCapital) : base(name, dateOfStart, bullstatt)
        {
            this.OwnerName = ownerName;
            this.CurrentCapital = currentCapital;
            this.FirstCapital = firstCapital;
        }

        public string OwnerName
        {
            get { return this.ownerName; }
            set 
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("The owner's name cannot be null or empty!");
                }
                else
                {
                    this.ownerName = value;
                } 
            }
        }

        public double CurrentCapital
        {
            get { return this.currentCapital; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("The current balance cannot br smaller or equal to zero!");
                }
                else
                {
                    this.currentCapital = value;
                }
            }
        }

        public double FirstCapital
        {
            get { return this.firstCapital; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("The first balance cannot br smaller or equal to zero!");
                }
                else
                {
                    this.firstCapital = value;
                }
            }
        }

        public double CalculateTax()
        {
            return (this.CurrentCapital - this.FirstCapital) * 0.15;
        }
    }
}
