﻿namespace project_23
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
