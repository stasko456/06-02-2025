﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_23
{
    public class Company
    {
		private string name;
        private string dateOfStart;
        private string bullstatt;

        public Company(string name, string dateOfStart, string bullstatt)
        {
			this.Name = name;
			this.DateOfStart = dateOfStart;
			this.Bullstatt = bullstatt;
        }

        public string Name
		{
			get { return this.name; }
			set
			{
				if (string.IsNullOrEmpty(value))
				{
					throw new ArgumentException("Name cannot be null or empty!");
				}
				else
				{
                    this.name = value;
                }
            }
		}

		public string DateOfStart
        {
			get { return this.dateOfStart; }
			set 
			{
				if (string.IsNullOrEmpty(value))
				{
					throw new ArgumentException("Date of start cannot be null or empty!");
				}
				else
				{
                    this.dateOfStart = value;
                }
			}
		}

		public string Bullstatt
		{
			get { return this.bullstatt; }
			set 
			{
                if (string.IsNullOrEmpty(value) || value.Length != 10)
                {
					throw new ArgumentException("The bullstatt cannot be null or empty!");
                }
				else
				{
                    this.bullstatt = value;
                } 
			}
		}
    }
}
