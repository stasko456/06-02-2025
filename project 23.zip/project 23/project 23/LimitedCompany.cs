﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project_23
{
    public class LimitedCompany: Company
    {
		private string articlesOfIncorporation;
        private double currentCapital;

        public LimitedCompany(string name, string dateOfStart, string bullstatt, string articlesOfIncorporation, double currentCapital) : base(name, dateOfStart, bullstatt)
        {
            this.ArticlesOfIncorporation = articlesOfIncorporation;
            this.currentCapital = currentCapital;
        }

        public string ArticlesOfIncorporation
        {
			get { return this.articlesOfIncorporation; }
			set 
			{
				if (string.IsNullOrEmpty(value))
				{
					throw new ArgumentException("The article of incorporation cannot be null or empty!");
				}
				else
				{
                    this.articlesOfIncorporation = value;
                } 
			}
		}

        public double CurrentCapital
        {
            get { return this.currentCapital; }
            set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("The current balance cannot br smaller or equal to zero!");
                }
                else
                {
                    this.currentCapital = value;
                }
            }
        }

        public double CalculateTax()
        {
            return (this.CurrentCapital - 2) * 0.1 ;
        }
    }
}
